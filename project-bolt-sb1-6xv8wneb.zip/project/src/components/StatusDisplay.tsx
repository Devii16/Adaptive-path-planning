import type { VehicleState } from '@/sim/types';
import { AlertTriangle, Navigation, CheckCircle2, Radar, Pause, Loader2 } from 'lucide-react';

const STATUS_CONFIG: Record<
  VehicleState,
  { color: string; bg: string; border: string; icon: typeof Navigation; pulse?: boolean }
> = {
  IDLE: { color: '#94a3b8', bg: '#1e293b', border: '#475569', icon: Pause },
  SCANNING: { color: '#06b6d4', bg: '#0c4a6e', border: '#0891b2', icon: Radar, pulse: true },
  PLANNING: { color: '#facc15', bg: '#713f12', border: '#ca8a04', icon: Loader2, pulse: true },
  DRIVING: { color: '#22c55e', bg: '#14532d', border: '#16a34a', icon: Navigation },
  OBSTACLE_DETECTED: { color: '#f97316', bg: '#7c2d12', border: '#ea580c', icon: AlertTriangle, pulse: true },
  REPLANNING: { color: '#facc15', bg: '#713f12', border: '#ca8a04', icon: Loader2, pulse: true },
  NEW_PATH_FOUND: { color: '#06b6d4', bg: '#0c4a6e', border: '#0891b2', icon: CheckCircle2 },
  AVOIDING_OBSTACLE: { color: '#f97316', bg: '#7c2d12', border: '#ea580c', icon: AlertTriangle, pulse: true },
  DESTINATION_REACHED: { color: '#22c55e', bg: '#14532d', border: '#16a34a', icon: CheckCircle2 },
  BLOCKED: { color: '#ef4444', bg: '#7f1d1d', border: '#dc2626', icon: AlertTriangle, pulse: true },
};

interface StatusDisplayProps {
  status: VehicleState;
}

export default function StatusDisplay({ status }: StatusDisplayProps) {
  const config = STATUS_CONFIG[status];
  const Icon = config.icon;

  return (
    <div
      className={`rounded-xl border-2 px-4 py-3 flex items-center gap-3 transition-all duration-300 ${config.pulse ? 'animate-pulse' : ''}`}
      style={{
        color: config.color,
        backgroundColor: config.bg,
        borderColor: config.border,
      }}
    >
      <Icon size={24} className={config.pulse ? 'animate-spin-slow' : ''} style={{ color: config.color }} />
      <div className="flex-1">
        <div className="text-[10px] uppercase tracking-widest opacity-60">Autonomous Vehicle Status</div>
        <div className="text-lg font-bold tracking-wide">{status.replace(/_/g, ' ')}</div>
      </div>
      <div className="flex gap-1">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="w-2 h-2 rounded-full"
            style={{
              backgroundColor: config.color,
              opacity: config.pulse ? 1 - i * 0.25 : 0.4,
            }}
          />
        ))}
      </div>
    </div>
  );
}
