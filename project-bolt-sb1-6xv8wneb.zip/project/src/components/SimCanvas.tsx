import { useEffect, useRef } from 'react';
import type { SimState, Obstacle, ObstacleType } from '@/sim/types';
import { SIM_CONFIG } from '@/sim/world';

interface SimCanvasProps {
  state: SimState;
  onClickAddObstacle?: (type: ObstacleType, x: number, y: number) => void;
}

const OBSTACLE_COLORS: Record<ObstacleType, { fill: string; stroke: string }> = {
  car: { fill: '#3b82f6', stroke: '#93c5fd' },
  motorcycle: { fill: '#f59e0b', stroke: '#fcd34d' },
  rickshaw: { fill: '#10b981', stroke: '#6ee7b7' },
  pedestrian: { fill: '#ef4444', stroke: '#fca5a5' },
  pushcart: { fill: '#a78bfa', stroke: '#c4b5fd' },
  animal: { fill: '#92400e', stroke: '#d97706' },
  cow: { fill: '#78350f', stroke: '#b45309' },
  barrier: { fill: '#fbbf24', stroke: '#fde68a' },
};

const OBSTACLE_ICONS: Record<ObstacleType, string> = {
  car: 'CAR',
  motorcycle: 'MC',
  rickshaw: 'AR',
  pedestrian: 'P',
  pushcart: 'PC',
  animal: 'DOG',
  cow: 'COW',
  barrier: 'BAR',
};

export default function SimCanvas({ state, onClickAddObstacle }: SimCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId: number;

    const render = () => {
      const s = stateRef.current;
      const { width, height } = SIM_CONFIG.grid;
      ctx.clearRect(0, 0, width, height);

      // Background road
      ctx.fillStyle = '#1a1a24';
      ctx.fillRect(0, 0, width, height);

      // Road surface
      const roadGrad = ctx.createLinearGradient(0, 0, 0, height);
      roadGrad.addColorStop(0, '#2a2a36');
      roadGrad.addColorStop(0.5, '#22222e');
      roadGrad.addColorStop(1, '#2a2a36');
      ctx.fillStyle = roadGrad;
      ctx.fillRect(0, 60, width, height - 120);

      // Road edges (irregular)
      ctx.strokeStyle = '#4a4a5a';
      ctx.lineWidth = 2;
      ctx.setLineDash([15, 8, 20, 5]);
      ctx.beginPath();
      ctx.moveTo(0, 60);
      for (let x = 0; x <= width; x += 30) {
        ctx.lineTo(x, 60 + Math.sin(x * 0.02) * 8);
      }
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, height - 60);
      for (let x = 0; x <= width; x += 30) {
        ctx.lineTo(x, height - 60 + Math.sin(x * 0.02) * 8);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Center dashed line
      ctx.strokeStyle = '#fbbf2440';
      ctx.lineWidth = 2;
      ctx.setLineDash([20, 15]);
      ctx.beginPath();
      ctx.moveTo(0, height / 2);
      ctx.lineTo(width, height / 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Grid overlay
      ctx.strokeStyle = '#ffffff08';
      ctx.lineWidth = 0.5;
      const cellSize = SIM_CONFIG.grid.cellSize;
      for (let x = 0; x <= width; x += cellSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y <= height; y += cellSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Start point
      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.arc(s.start.x, s.start.y, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#86efac';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('START', s.start.x, s.start.y - 15);

      // Destination
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(s.destination.x, s.destination.y, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#fca5a5';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(s.destination.x, s.destination.y, 16, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = '#fca5a5';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('GOAL', s.destination.x, s.destination.y - 18);

      // Blocked path (red)
      if (s.blockedPath && s.blockedPath.length > 1) {
        ctx.strokeStyle = '#ef444480';
        ctx.lineWidth = 4;
        ctx.setLineDash([8, 4]);
        ctx.beginPath();
        ctx.moveTo(s.blockedPath[0].x, s.blockedPath[0].y);
        for (let i = 1; i < s.blockedPath.length; i++) {
          ctx.lineTo(s.blockedPath[i].x, s.blockedPath[i].y);
        }
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Current path
      if (s.path.length > 1) {
        const isReplanning = s.status === 'REPLANNING' || s.status === 'NEW_PATH_FOUND';
        if (isReplanning) {
          ctx.strokeStyle = '#facc15';
          ctx.lineWidth = 3;
          ctx.setLineDash([10, 6]);
        } else if (s.status === 'DRIVING' || s.status === 'AVOIDING_OBSTACLE') {
          ctx.strokeStyle = '#3b82f6';
          ctx.lineWidth = 3;
        } else {
          ctx.strokeStyle = '#22c55e80';
          ctx.lineWidth = 2;
        }
        ctx.beginPath();
        ctx.moveTo(s.path[0].x, s.path[0].y);
        for (let i = 1; i < s.path.length; i++) {
          ctx.lineTo(s.path[i].x, s.path[i].y);
        }
        ctx.stroke();
        ctx.setLineDash([]);

        // Waypoint dots
        if (!isReplanning) {
          ctx.fillStyle = '#60a5fa';
          for (let i = s.currentWaypointIndex + 1; i < s.path.length; i++) {
            ctx.beginPath();
            ctx.arc(s.path[i].x, s.path[i].y, 3, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      // Obstacles
      for (const obs of s.obstacles) {
        drawObstacle(ctx, obs);
      }

      // Radar range (outer circle)
      ctx.strokeStyle = '#06b6d430';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.arc(s.vehicle.x, s.vehicle.y, 200, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Camera FOV cone
      const fovRad = (60 / 2) * (Math.PI / 180);
      const camRange = 100;
      ctx.fillStyle = '#22c55e15';
      ctx.strokeStyle = '#22c55e30';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(s.vehicle.x, s.vehicle.y);
      ctx.arc(
        s.vehicle.x,
        s.vehicle.y,
        camRange,
        s.vehicle.heading - fovRad,
        s.vehicle.heading + fovRad,
      );
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // LiDAR rays
      for (const ray of s.sensors.lidarRays) {
        if (ray.hit) {
          ctx.strokeStyle = '#f9731650';
          ctx.lineWidth = 1;
        } else {
          ctx.strokeStyle = '#06b6d420';
          ctx.lineWidth = 0.5;
        }
        ctx.beginPath();
        ctx.moveTo(s.vehicle.x, s.vehicle.y);
        ctx.lineTo(
          s.vehicle.x + Math.cos(ray.angle) * ray.distance,
          s.vehicle.y + Math.sin(ray.angle) * ray.distance,
        );
        ctx.stroke();

        if (ray.hit) {
          ctx.fillStyle = '#f97316';
          ctx.beginPath();
          ctx.arc(
            s.vehicle.x + Math.cos(ray.angle) * ray.distance,
            s.vehicle.y + Math.sin(ray.angle) * ray.distance,
            2,
            0,
            Math.PI * 2,
          );
          ctx.fill();
        }
      }

      // Vehicle
      drawVehicle(ctx, s);

      rafId = requestAnimationFrame(render);
    };

    rafId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafId);
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!onClickAddObstacle) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = SIM_CONFIG.grid.width / rect.width;
    const scaleY = SIM_CONFIG.grid.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    const types: ObstacleType[] = ['barrier', 'cow', 'pedestrian', 'pushcart'];
    const type = types[Math.floor(Math.random() * types.length)];
    onClickAddObstacle(type, x, y);
  };

  return (
    <canvas
      ref={canvasRef}
      width={SIM_CONFIG.grid.width}
      height={SIM_CONFIG.grid.height}
      onClick={handleClick}
      className="w-full h-auto rounded-lg cursor-crosshair"
      style={{ aspectRatio: '1000 / 600' }}
    />
  );
}

function drawVehicle(ctx: CanvasRenderingContext2D, s: SimState): void {
  const { vehicle } = s;
  ctx.save();
  ctx.translate(vehicle.x, vehicle.y);
  ctx.rotate(vehicle.heading);

  // Safety zone
  ctx.strokeStyle = '#facc1540';
  ctx.lineWidth = 1;
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  ctx.arc(0, 0, 30, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);

  // Vehicle body
  ctx.fillStyle = '#06b6d4';
  ctx.strokeStyle = '#67e8f9';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(-vehicle.length / 2, -vehicle.width / 2, vehicle.length, vehicle.width, 4);
  ctx.fill();
  ctx.stroke();

  // Direction indicator (front)
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(vehicle.length / 2 - 2, 0);
  ctx.lineTo(vehicle.length / 2 - 8, -5);
  ctx.lineTo(vehicle.length / 2 - 8, 5);
  ctx.closePath();
  ctx.fill();

  // Sensor dome
  ctx.fillStyle = '#0ea5e9';
  ctx.beginPath();
  ctx.arc(0, 0, 4, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function drawObstacle(ctx: CanvasRenderingContext2D, obs: Obstacle): void {
  const colors = OBSTACLE_COLORS[obs.type];
  ctx.save();
  ctx.translate(obs.x, obs.y);

  // Movement indicator
  if (obs.moving) {
    ctx.strokeStyle = colors.stroke + '60';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(obs.vx * 20, obs.vy * 20);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Body
  ctx.fillStyle = colors.fill;
  ctx.strokeStyle = colors.stroke;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, obs.radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Label
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 8px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(OBSTACLE_ICONS[obs.type], 0, 0);

  ctx.restore();
}
