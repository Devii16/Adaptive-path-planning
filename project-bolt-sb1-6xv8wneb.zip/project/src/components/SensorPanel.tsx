import type { SimState } from '@/sim/types';
import { Camera, Radar, ScanLine, Layers } from 'lucide-react';

interface SensorPanelProps {
  state: SimState;
}

function SensorStatus({
  icon: Icon,
  name,
  active,
  detail,
}: {
  icon: typeof Camera;
  name: string;
  active: boolean;
  detail: string;
}) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-slate-700/40 last:border-0">
      <div className="flex items-center gap-2 text-slate-400 text-xs">
        <Icon size={14} className={active ? 'text-cyan-400' : 'text-slate-600'} />
        {name}
      </div>
      <div className="flex items-center gap-2">
        <span className="text-xs text-slate-500 font-mono">{detail}</span>
        <span
          className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
            active ? 'bg-emerald-900/60 text-emerald-400' : 'bg-slate-800 text-slate-500'
          }`}
        >
          {active ? 'Online' : 'Off'}
        </span>
      </div>
    </div>
  );
}

const RISK_COLORS: Record<string, string> = {
  High: 'text-red-400',
  Medium: 'text-amber-400',
  Low: 'text-emerald-400',
};

export default function SensorPanel({ state }: SensorPanelProps) {
  const objects = state.sensors.detectedObjects.slice(0, 6);

  return (
    <div className="bg-slate-900/80 rounded-xl border border-slate-700/50 p-4">
      <h3 className="text-cyan-400 text-xs font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
        <Layers size={14} /> Sensor Fusion
      </h3>

      <SensorStatus icon={Camera} name="Camera" active={true} detail={`${state.sensors.cameraFOV}° FOV`} />
      <SensorStatus icon={ScanLine} name="LiDAR" active={true} detail={`${state.sensors.lidarRays.length} rays`} />
      <SensorStatus icon={Radar} name="Radar" active={true} detail={`${state.sensors.radarContacts.length} contacts`} />
      <SensorStatus
        icon={Layers}
        name="Fusion"
        active={true}
        detail={`${state.sensors.detectedObjects.length} objects`}
      />

      {objects.length > 0 && (
        <div className="mt-3 pt-3 border-t border-slate-700/40">
          <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-2">
            Detected Objects
          </div>
          <div className="space-y-1">
            {objects.map((obj, i) => (
              <div
                key={i}
                className="flex items-center justify-between text-xs py-1 px-2 rounded bg-slate-800/40"
              >
                <span className="text-slate-300 font-medium">{obj.label}</span>
                <div className="flex items-center gap-3">
                  <span className="text-slate-500 font-mono">{obj.distance}m</span>
                  <span className="text-slate-600 text-[10px]">{obj.source}</span>
                  <span className={`font-bold ${RISK_COLORS[obj.risk]}`}>{obj.risk}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
