import type { SimState } from '@/sim/types';
import { Route, GitBranch, Network, Map, CheckCircle2 } from 'lucide-react';

interface PathPanelProps {
  state: SimState;
}

function InfoRow({
  icon: Icon,
  label,
  value,
  unit,
  color = '#86efac',
}: {
  icon: typeof Route;
  label: string;
  value: string | number;
  unit?: string;
  color?: string;
}) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-slate-700/40 last:border-0">
      <div className="flex items-center gap-2 text-slate-400 text-xs">
        <Icon size={14} style={{ color }} />
        {label}
      </div>
      <div className="text-sm font-mono font-semibold text-slate-100">
        {value}
        {unit && <span className="text-slate-500 ml-1 text-xs">{unit}</span>}
      </div>
    </div>
  );
}

export default function PathPanel({ state }: PathPanelProps) {
  const planningStatus =
    state.status === 'REPLANNING'
      ? 'Replanning'
      : state.status === 'NEW_PATH_FOUND'
        ? 'New Path Found'
        : state.status === 'PLANNING'
          ? 'Planning'
          : state.status === 'BLOCKED'
            ? 'No Path'
            : 'Active';

  return (
    <div className="bg-slate-900/80 rounded-xl border border-slate-700/50 p-4">
      <h3 className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
        <Route size={14} /> Path Planning
      </h3>
      <InfoRow icon={GitBranch} label="Algorithm" value="A*" color="#86efac" />
      <InfoRow icon={Map} label="Path Length" value={state.pathLength.toFixed(0)} unit="m" />
      <InfoRow icon={Route} label="Replan Count" value={state.replanCount} color="#facc15" />
      <InfoRow icon={Network} label="Nodes Explored" value={state.nodesExplored} />
      <InfoRow
        icon={CheckCircle2}
        label="Planning Status"
        value={planningStatus}
        color={state.status === 'BLOCKED' ? '#ef4444' : '#86efac'}
      />
    </div>
  );
}
