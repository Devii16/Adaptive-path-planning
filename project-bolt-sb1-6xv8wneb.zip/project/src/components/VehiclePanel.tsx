import type { SimState } from '@/sim/types';
import { Gauge, Compass, MapPin, Flag } from 'lucide-react';

interface VehiclePanelProps {
  state: SimState;
}

function InfoRow({
  icon: Icon,
  label,
  value,
  unit,
  color = '#67e8f9',
}: {
  icon: typeof Gauge;
  label: string;
  value: string | number;
  unit?: string;
  color?: string;
}) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-slate-700/40 last:border-0">
      <div className="flex items-center gap-2 text-slate-400 text-xs">
        <Icon size={14} style={{ color }} />
        {label}
      </div>
      <div className="text-sm font-mono font-semibold text-slate-100">
        {value}
        {unit && <span className="text-slate-500 ml-1 text-xs">{unit}</span>}
      </div>
    </div>
  );
}

export default function VehiclePanel({ state }: VehiclePanelProps) {
  const speedKmh = (state.speed * 3.6 * 10).toFixed(1);
  const headingDeg = ((state.heading * 180) / Math.PI + 360) % 360;

  return (
    <div className="bg-slate-900/80 rounded-xl border border-slate-700/50 p-4">
      <h3 className="text-cyan-400 text-xs font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
        <Gauge size={14} /> Vehicle Telemetry
      </h3>
      <InfoRow icon={Gauge} label="Speed" value={speedKmh} unit="km/h" />
      <InfoRow icon={Compass} label="Heading" value={headingDeg.toFixed(0)} unit="°" />
      <InfoRow icon={MapPin} label="Position X" value={state.vehicle.x.toFixed(0)} />
      <InfoRow icon={MapPin} label="Position Y" value={state.vehicle.y.toFixed(0)} />
      <InfoRow icon={Flag} label="Dist to Goal" value={state.distanceToDestination.toFixed(0)} unit="m" color="#fca5a5" />
    </div>
  );
}
