import type { SimState } from '@/sim/types';
import { ShieldAlert, AlertTriangle, Eye, ShieldCheck } from 'lucide-react';

interface SafetyPanelProps {
  state: SimState;
}

function InfoRow({
  icon: Icon,
  label,
  value,
  unit,
  color = '#fca5a5',
}: {
  icon: typeof ShieldAlert;
  label: string;
  value: string | number;
  unit?: string;
  color?: string;
}) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-slate-700/40 last:border-0">
      <div className="flex items-center gap-2 text-slate-400 text-xs">
        <Icon size={14} style={{ color }} />
        {label}
      </div>
      <div className="text-sm font-mono font-semibold" style={{ color }}>
        {value}
        {unit && <span className="text-slate-500 ml-1 text-xs">{unit}</span>}
      </div>
    </div>
  );
}

export default function SafetyPanel({ state }: SafetyPanelProps) {
  const riskColor =
    state.collisionRisk === 'High'
      ? '#ef4444'
      : state.collisionRisk === 'Medium'
        ? '#f97316'
        : state.collisionRisk === 'Low'
          ? '#facc15'
          : '#22c55e';

  return (
    <div className="bg-slate-900/80 rounded-xl border border-slate-700/50 p-4">
      <h3 className="text-red-400 text-xs font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
        <ShieldAlert size={14} /> Safety & Collision
      </h3>
      <InfoRow
        icon={AlertTriangle}
        label="Collision Risk"
        value={state.collisionRisk}
        color={riskColor}
      />
      <InfoRow
        icon={Eye}
        label="Nearest Obstacle"
        value={state.nearestObstacleDistance.toFixed(0)}
        unit="m"
        color={riskColor}
      />
      <InfoRow icon={Eye} label="Obstacles Detected" value={state.obstacles.length} color="#fca5a5" />
      <InfoRow
        icon={ShieldCheck}
        label="Obstacles Avoided"
        value={state.obstaclesAvoided}
        color="#86efac"
      />
    </div>
  );
}
