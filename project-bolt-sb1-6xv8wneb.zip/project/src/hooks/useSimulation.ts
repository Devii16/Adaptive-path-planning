import { useCallback, useEffect, useRef, useState } from 'react';
import type { SimState, VehicleState, ObstacleType } from '@/sim/types';
import { SimulationEngine } from '@/sim/engine';

export interface SimulationControls {
  state: SimState;
  status: VehicleState;
  isRunning: boolean;
  start: () => void;
  pause: () => void;
  reset: () => void;
  addSuddenObstacle: () => void;
  addObstacleAt: (type: ObstacleType, x: number, y: number) => void;
  addRandomTraffic: () => void;
  clearObstacles: () => void;
  recalculatePath: () => void;
}

export function useSimulation(): SimulationControls {
  const engineRef = useRef<SimulationEngine | null>(null);
  if (!engineRef.current) {
    engineRef.current = new SimulationEngine();
  }
  const engine = engineRef.current;

  const [state, setState] = useState<SimState>(engine.state);
  const [status, setStatus] = useState<VehicleState>(engine.state.status);
  const [isRunning, setIsRunning] = useState(false);

  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    let rafId: number;
    let lastUpdate = 0;
    const TICK_INTERVAL = 1000 / 60;

    const tick = (timestamp: number) => {
      if (timestamp - lastUpdate >= TICK_INTERVAL) {
        engine.step();
        const newState = { ...engine.state };
        setState(newState);
        setStatus(engine.state.status);
        lastUpdate = timestamp;
      }
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [engine]);

  const start = useCallback(() => {
    engine.start();
    setIsRunning(engine.isRunning());
  }, [engine]);

  const pause = useCallback(() => {
    engine.pause();
    setIsRunning(engine.isRunning());
  }, [engine]);

  const reset = useCallback(() => {
    engine.reset();
    setState({ ...engine.state });
    setStatus(engine.state.status);
    setIsRunning(false);
  }, [engine]);

  const addSuddenObstacle = useCallback(() => {
    engine.addSuddenObstacle();
  }, [engine]);

  const addObstacleAt = useCallback(
    (type: ObstacleType, x: number, y: number) => {
      engine.addObstacleAt(type, x, y);
    },
    [engine],
  );

  const addRandomTraffic = useCallback(() => {
    engine.addRandomTraffic();
  }, [engine]);

  const clearObstacles = useCallback(() => {
    engine.clearObstacles();
  }, [engine]);

  const recalculatePath = useCallback(() => {
    engine.recalculatePath();
  }, [engine]);

  return {
    state,
    status,
    isRunning,
    start,
    pause,
    reset,
    addSuddenObstacle,
    addObstacleAt,
    addRandomTraffic,
    clearObstacles,
    recalculatePath,
  };
}
