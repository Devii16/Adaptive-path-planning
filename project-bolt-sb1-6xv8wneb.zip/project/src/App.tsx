import { Car, Zap } from 'lucide-react';
import { useSimulation } from '@/hooks/useSimulation';
import SimCanvas from '@/components/SimCanvas';
import StatusDisplay from '@/components/StatusDisplay';
import ControlPanel from '@/components/ControlPanel';
import VehiclePanel from '@/components/VehiclePanel';
import PathPanel from '@/components/PathPanel';
import SafetyPanel from '@/components/SafetyPanel';
import SensorPanel from '@/components/SensorPanel';

export default function App() {
  const sim = useSimulation();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-[1600px] mx-auto px-4 py-3 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Car size={22} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-100 leading-tight">
                Adaptive Path Planning & Collision Avoidance
              </h1>
              <p className="text-xs text-slate-500">
                Autonomous Vehicles on Unstructured Indian Roads
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-1 rounded-md bg-slate-800 text-[10px] text-slate-400 font-mono border border-slate-700">
              A* PATHFINDER
            </span>
            <span className="px-2 py-1 rounded-md bg-cyan-900/40 text-[10px] text-cyan-400 font-mono border border-cyan-800">
              SIH DEMO
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-[1600px] mx-auto px-4 py-4">
        {/* Status Bar */}
        <div className="mb-4">
          <StatusDisplay status={sim.status} />
        </div>

        {/* Controls */}
        <div className="mb-4 bg-slate-900/60 rounded-xl border border-slate-700/50 p-3">
          <ControlPanel
            isRunning={sim.isRunning}
            onStart={sim.start}
            onPause={sim.pause}
            onReset={sim.reset}
            onAddSuddenObstacle={sim.addSuddenObstacle}
            onAddRandomTraffic={sim.addRandomTraffic}
            onClearObstacles={sim.clearObstacles}
            onRecalculatePath={sim.recalculatePath}
          />
        </div>

        {/* Simulation + Side Panels */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4">
          {/* Simulation Canvas */}
          <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-3 relative overflow-hidden">
            <div className="absolute top-5 left-5 z-10 flex items-center gap-2 text-[10px] font-mono text-slate-500">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500" /> Start
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-red-500" /> Goal
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-0.5 bg-blue-500" /> Active Path
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-0.5 bg-yellow-400" style={{ borderTop: '1px dashed' }} /> Replanning
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-0.5 bg-red-500" style={{ borderTop: '1px dashed' }} /> Blocked
              </span>
            </div>
            <div className="absolute top-5 right-5 z-10 text-[10px] font-mono text-slate-600">
              Click on map to add obstacle
            </div>
            <SimCanvas state={sim.state} onClickAddObstacle={sim.addObstacleAt} />
          </div>

          {/* Right Panel: Info Panels */}
          <div className="space-y-3">
            <VehiclePanel state={sim.state} />
            <PathPanel state={sim.state} />
            <SafetyPanel state={sim.state} />
            <SensorPanel state={sim.state} />
          </div>
        </div>

        {/* Quick Actions Hint */}
        <div className="mt-4 bg-slate-900/40 rounded-xl border border-slate-800 p-3 flex items-center gap-3 text-xs text-slate-500">
          <Zap size={14} className="text-amber-400" />
          <span>
            Press <strong className="text-amber-400">Add Sudden Obstacle</strong> to drop a barrier directly on the vehicle's path.
            The vehicle will detect it, replan using A*, and automatically resume driving.
          </span>
        </div>

        {/* Footer */}
        <footer className="mt-4 pt-4 border-t border-slate-800 text-center text-xs text-slate-600">
          <p>
            Simulated Camera + LiDAR + Radar sensor fusion with A* dynamic replanning.
            Designed for unstructured Indian road environments.
          </p>
        </footer>
      </main>
    </div>
  );
}
