export type Point = { x: number; y: number };

export type VehicleState =
  | 'IDLE'
  | 'SCANNING'
  | 'PLANNING'
  | 'DRIVING'
  | 'OBSTACLE_DETECTED'
  | 'REPLANNING'
  | 'NEW_PATH_FOUND'
  | 'AVOIDING_OBSTACLE'
  | 'DESTINATION_REACHED'
  | 'BLOCKED';

export type ObstacleType =
  | 'car'
  | 'motorcycle'
  | 'rickshaw'
  | 'pedestrian'
  | 'pushcart'
  | 'animal'
  | 'barrier'
  | 'cow';

export interface Obstacle {
  id: string;
  type: ObstacleType;
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
  moving: boolean;
  label: string;
}

export interface DetectedObject {
  type: ObstacleType;
  label: string;
  distance: number;
  bearing: number;
  risk: 'Low' | 'Medium' | 'High';
  source: 'Camera' | 'LiDAR' | 'Radar' | 'Fusion';
}

export interface Vehicle {
  x: number;
  y: number;
  heading: number;
  speed: number;
  maxSpeed: number;
  width: number;
  length: number;
}

export interface SensorReadings {
  lidarRays: { angle: number; distance: number; hit: boolean }[];
  radarRange: number;
  radarContacts: { angle: number; distance: number; velocity: number }[];
  cameraFOV: number;
  cameraRange: number;
  detectedObjects: DetectedObject[];
}

export interface SimState {
  vehicle: Vehicle;
  destination: Point;
  start: Point;
  obstacles: Obstacle[];
  path: Point[];
  currentWaypointIndex: number;
  status: VehicleState;
  replanCount: number;
  nodesExplored: number;
  obstaclesAvoided: number;
  collisionRisk: 'None' | 'Low' | 'Medium' | 'High';
  nearestObstacleDistance: number;
  sensors: SensorReadings;
  speed: number;
  heading: number;
  pathLength: number;
  distanceToDestination: number;
  blockedPath: Point[] | null;
  replanningActive: boolean;
}

export interface GridConfig {
  width: number;
  height: number;
  cellSize: number;
  cols: number;
  rows: number;
}

export interface SimConfig {
  grid: GridConfig;
  safetyMargin: number;
  replanCooldown: number;
  vehicleSpeed: number;
  steeringRate: number;
  waypointReachThreshold: number;
}
