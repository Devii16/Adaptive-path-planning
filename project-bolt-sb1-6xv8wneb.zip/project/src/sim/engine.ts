import type {
  Obstacle,
  Point,
  SimState,
  Vehicle,
  VehicleState,
  ObstacleType,
} from './types';
import type { SimConfig } from './types';
import { aStar, buildGrid, isPathBlocked, pathLength } from './pathfinding';
import { runSensors, computeCollisionRisk } from './sensors';
import {
  SIM_CONFIG,
  START_POINT,
  DESTINATION_POINT,
  createInitialObstacles,
  createObstacleOnPath,
  createRandomTraffic,
  makeObstacle,
} from './world';

export function createInitialState(): SimState {
  const vehicle: Vehicle = {
    x: START_POINT.x,
    y: START_POINT.y,
    heading: 0,
    speed: 0,
    maxSpeed: SIM_CONFIG.vehicleSpeed,
    width: 18,
    length: 32,
  };

  const obstacles = createInitialObstacles();
  const grid = buildGrid(obstacles, SIM_CONFIG.grid, SIM_CONFIG.safetyMargin);
  const result = aStar(START_POINT, DESTINATION_POINT, grid, SIM_CONFIG.grid);

  const sensors = runSensors(vehicle, obstacles);
  const collision = computeCollisionRisk(vehicle, obstacles, SIM_CONFIG.safetyMargin);

  return {
    vehicle,
    destination: { ...DESTINATION_POINT },
    start: { ...START_POINT },
    obstacles,
    path: result.path,
    currentWaypointIndex: 0,
    status: 'IDLE',
    replanCount: 0,
    nodesExplored: result.nodesExplored,
    obstaclesAvoided: 0,
    collisionRisk: collision.risk,
    nearestObstacleDistance: collision.nearestDistance,
    sensors,
    speed: 0,
    heading: 0,
    pathLength: pathLength(result.path),
    distanceToDestination: Math.hypot(
      DESTINATION_POINT.x - vehicle.x,
      DESTINATION_POINT.y - vehicle.y,
    ),
    blockedPath: null,
    replanningActive: false,
  };
}

function planPath(
  start: Point,
  goal: Point,
  obstacles: Obstacle[],
  config: SimConfig,
): { path: Point[]; nodesExplored: number; success: boolean } {
  const grid = buildGrid(obstacles, config.grid, config.safetyMargin);
  const result = aStar(start, goal, grid, config.grid);
  return { path: result.path, nodesExplored: result.nodesExplored, success: result.success };
}

function normalizeAngle(a: number): number {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function updateMovingObstacles(state: SimState, config: SimConfig): void {
  for (const obs of state.obstacles) {
    if (!obs.moving) continue;
    obs.x += obs.vx;
    obs.y += obs.vy;
    if (obs.x < 30 || obs.x > config.grid.width - 30) obs.vx *= -1;
    if (obs.y < 30 || obs.y > config.grid.height - 30) obs.vy *= -1;
  }
}

interface EngineCallbacks {
  onStatusChange?: (status: VehicleState) => void;
}

export class SimulationEngine {
  state: SimState;
  config: SimConfig;
  private running = false;
  private replanCooldown = 0;
  private callbacks: EngineCallbacks;
  private frameCount = 0;

  constructor(callbacks: EngineCallbacks = {}) {
    this.config = SIM_CONFIG;
    this.state = createInitialState();
    this.callbacks = callbacks;
  }

  start(): void {
    if (this.state.status === 'DESTINATION_REACHED') return;
    this.running = true;
    if (
      this.state.status === 'IDLE' ||
      this.state.status === 'BLOCKED' ||
      this.state.status === 'NEW_PATH_FOUND'
    ) {
      this.setStatus('DRIVING');
      this.state.replanningActive = false;
      this.state.blockedPath = null;
      this.state.vehicle.speed = this.config.vehicleSpeed;
    }
  }

  pause(): void {
    this.running = false;
    if (this.state.status === 'DRIVING' || this.state.status === 'AVOIDING_OBSTACLE') {
      this.setStatus('IDLE');
    }
  }

  reset(): void {
    this.running = false;
    this.replanCooldown = 0;
    this.frameCount = 0;
    this.state = createInitialState();
  }

  isRunning(): boolean {
    return this.running;
  }

  private setStatus(status: VehicleState): void {
    if (this.state.status !== status) {
      this.state.status = status;
      this.callbacks.onStatusChange?.(status);
    }
  }

  addSuddenObstacle(): void {
    const obs = createObstacleOnPath(
      this.state.path,
      this.state.vehicle,
      100,
      350,
    );
    if (obs) {
      this.state.obstacles.push(obs);
      this.triggerReplan();
    }
  }

  addObstacleAt(type: ObstacleType, x: number, y: number): void {
    const obs = makeObstacle(type, x, y);
    this.state.obstacles.push(obs);
    this.triggerReplan();
  }

  addRandomTraffic(): void {
    const traffic = createRandomTraffic(this.config.grid, 4);
    this.state.obstacles.push(...traffic);
  }

  clearObstacles(): void {
    this.state.obstacles = [];
    this.state.blockedPath = null;
    this.triggerReplan();
  }

  recalculatePath(): void {
    this.triggerReplan();
  }

  private triggerReplan(): void {
    if (this.replanCooldown > 0) return;
    this.replanCooldown = this.config.replanCooldown;

    this.setStatus('OBSTACLE_DETECTED');
    this.state.replanningActive = true;
    this.state.vehicle.speed = 0;
    this.state.speed = 0;

    const startPos: Point = { x: this.state.vehicle.x, y: this.state.vehicle.y };
    const result = planPath(startPos, this.state.destination, this.state.obstacles, this.config);

    if (!result.success || result.path.length < 2) {
      this.setStatus('BLOCKED');
      this.state.replanningActive = false;
      this.state.speed = 0;
      this.state.vehicle.speed = 0;
      this.state.path = [];
      return;
    }

    const oldPath = this.state.path;
    this.state.path = result.path;
    this.state.currentWaypointIndex = 0;
    this.state.replanCount++;
    this.state.nodesExplored = result.nodesExplored;
    this.state.pathLength = pathLength(result.path);
    this.state.blockedPath = oldPath.length > 1 ? oldPath : null;
    this.state.obstaclesAvoided++;
    this.setStatus('REPLANNING');

    setTimeout(() => {
      if (this.state.status === 'REPLANNING') {
        this.setStatus('NEW_PATH_FOUND');
        setTimeout(() => {
          if (this.state.status === 'NEW_PATH_FOUND') {
            this.setStatus('DRIVING');
            this.state.replanningActive = false;
            this.state.blockedPath = null;
            this.replanCooldown = this.config.replanCooldown;
            if (this.running) {
              this.state.vehicle.speed = this.config.vehicleSpeed;
            }
          }
        }, 300);
      }
    }, 200);
  }

  step(): void {
    this.frameCount++;
    const inReplanState =
      this.state.status === 'OBSTACLE_DETECTED' ||
      this.state.status === 'REPLANNING' ||
      this.state.status === 'NEW_PATH_FOUND';
    if (this.replanCooldown > 0 && !inReplanState) this.replanCooldown--;

    updateMovingObstacles(this.state, this.config);

    if (!this.running) {
      this.state.sensors = runSensors(this.state.vehicle, this.state.obstacles);
      return;
    }

    if (
      this.state.status === 'DESTINATION_REACHED' ||
      this.state.status === 'BLOCKED' ||
      this.state.status === 'REPLANNING' ||
      this.state.status === 'OBSTACLE_DETECTED' ||
      this.state.status === 'NEW_PATH_FOUND'
    ) {
      this.state.sensors = runSensors(this.state.vehicle, this.state.obstacles);
      return;
    }

    const { vehicle, path, destination } = this.state;

    const distToDest = Math.hypot(destination.x - vehicle.x, destination.y - vehicle.y);
    this.state.distanceToDestination = distToDest;

    if (distToDest < 25) {
      vehicle.speed = 0;
      this.state.speed = 0;
      this.setStatus('DESTINATION_REACHED');
      this.state.sensors = runSensors(vehicle, this.state.obstacles);
      return;
    }

    if (path.length < 2 || this.state.currentWaypointIndex >= path.length - 1) {
      if (distToDest > 30) {
        this.triggerReplan();
      }
      this.state.sensors = runSensors(vehicle, this.state.obstacles);
      return;
    }

    const pathCheck = isPathBlocked(
      path,
      this.state.obstacles,
      this.config.safetyMargin - this.config.grid.cellSize / 2,
      this.state.currentWaypointIndex,
    );

    if (pathCheck.blocked && this.replanCooldown === 0) {
      this.state.blockedPath = pathCheck.blockedSegment
        ? [pathCheck.blockedSegment[0], pathCheck.blockedSegment[1]]
        : null;
      this.triggerReplan();
      this.state.sensors = runSensors(vehicle, this.state.obstacles);
      return;
    }

    const targetWaypoint = path[this.state.currentWaypointIndex + 1] || path[path.length - 1];
    const dx = targetWaypoint.x - vehicle.x;
    const dy = targetWaypoint.y - vehicle.y;
    const distToWaypoint = Math.hypot(dx, dy);

    if (distToWaypoint < this.config.waypointReachThreshold) {
      this.state.currentWaypointIndex++;
      if (this.state.currentWaypointIndex >= path.length - 1) {
        const finalDx = destination.x - vehicle.x;
        const finalDy = destination.y - vehicle.y;
        const finalDist = Math.hypot(finalDx, finalDy);
        if (finalDist < 25) {
          vehicle.speed = 0;
          this.state.speed = 0;
          this.setStatus('DESTINATION_REACHED');
          this.state.sensors = runSensors(vehicle, this.state.obstacles);
          return;
        }
      }
    }

    const targetHeading = Math.atan2(dy, dx);
    let angleDiff = normalizeAngle(targetHeading - vehicle.heading);
    const maxTurn = this.config.steeringRate;
    if (Math.abs(angleDiff) < maxTurn) {
      vehicle.heading = targetHeading;
    } else {
      vehicle.heading += Math.sign(angleDiff) * maxTurn;
    }

    const collision = computeCollisionRisk(vehicle, this.state.obstacles, this.config.safetyMargin);
    this.state.collisionRisk = collision.risk;
    this.state.nearestObstacleDistance = collision.nearestDistance;

    if (collision.risk === 'High' && this.replanCooldown === 0) {
      this.triggerReplan();
      this.state.sensors = runSensors(vehicle, this.state.obstacles);
      return;
    }

    if (collision.risk === 'High') {
      vehicle.speed = Math.max(0, vehicle.maxSpeed * 0.3);
      this.setStatus('AVOIDING_OBSTACLE');
    } else if (collision.risk === 'Medium') {
      vehicle.speed = vehicle.maxSpeed * 0.6;
      if (this.state.status !== 'DRIVING') this.setStatus('DRIVING');
    } else {
      vehicle.speed = vehicle.maxSpeed;
      if (this.state.status === 'AVOIDING_OBSTACLE') {
        this.setStatus('DRIVING');
      }
    }

    vehicle.x += Math.cos(vehicle.heading) * vehicle.speed;
    vehicle.y += Math.sin(vehicle.heading) * vehicle.speed;

    if (vehicle.x < 15) { vehicle.x = 15; vehicle.heading = Math.PI - vehicle.heading; }
    if (vehicle.x > this.config.grid.width - 15) { vehicle.x = this.config.grid.width - 15; vehicle.heading = Math.PI - vehicle.heading; }
    if (vehicle.y < 15) { vehicle.y = 15; vehicle.heading = -vehicle.heading; }
    if (vehicle.y > this.config.grid.height - 15) { vehicle.y = this.config.grid.height - 15; vehicle.heading = -vehicle.heading; }

    this.state.speed = vehicle.speed;
    this.state.heading = vehicle.heading;
    this.state.sensors = runSensors(vehicle, this.state.obstacles);
  }
}
