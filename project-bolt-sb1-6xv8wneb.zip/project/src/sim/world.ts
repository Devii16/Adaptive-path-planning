import type { Obstacle, ObstacleType, Point, GridConfig, SimConfig } from './types';

export const SIM_CONFIG: SimConfig = {
  grid: {
    width: 1000,
    height: 600,
    cellSize: 20,
    cols: 50,
    rows: 30,
  },
  safetyMargin: 18,
  replanCooldown: 60,
  vehicleSpeed: 1.8,
  steeringRate: 0.06,
  waypointReachThreshold: 22,
};

export const START_POINT: Point = { x: 60, y: 300 };
export const DESTINATION_POINT: Point = { x: 940, y: 300 };

const OBstacle_LABELS: Record<ObstacleType, string> = {
  car: 'Car',
  motorcycle: 'Motorcycle',
  rickshaw: 'Auto-rickshaw',
  pedestrian: 'Pedestrian',
  pushcart: 'Pushcart',
  animal: 'Dog',
  cow: 'Cow',
  barrier: 'Road Barrier',
};

let obstacleIdCounter = 0;

function makeObstacle(
  type: ObstacleType,
  x: number,
  y: number,
  moving = false,
  vx = 0,
  vy = 0,
): Obstacle {
  const radii: Record<ObstacleType, number> = {
    car: 16,
    motorcycle: 11,
    rickshaw: 15,
    pedestrian: 8,
    pushcart: 14,
    animal: 10,
    cow: 14,
    barrier: 12,
  };
  return {
    id: `obs-${obstacleIdCounter++}`,
    type,
    x,
    y,
    radius: radii[type],
    vx,
    vy,
    moving,
    label: OBstacle_LABELS[type],
  };
}

export function createInitialObstacles(): Obstacle[] {
  const obstacles: Obstacle[] = [];
  obstacles.push(makeObstacle('rickshaw', 250, 200, true, 0.4, 0));
  obstacles.push(makeObstacle('motorcycle', 350, 380, true, 0.6, -0.2));
  obstacles.push(makeObstacle('pedestrian', 500, 150, true, 0.2, 0.3));
  obstacles.push(makeObstacle('pushcart', 600, 420));
  obstacles.push(makeObstacle('car', 700, 220, true, 0.3, 0));
  obstacles.push(makeObstacle('cow', 400, 480));
  obstacles.push(makeObstacle('barrier', 800, 350));
  obstacles.push(makeObstacle('animal', 150, 450));
  return obstacles;
}

export function createObstacleOnPath(
  path: Point[],
  vehiclePos: Point,
  minDistAhead = 120,
  maxDistAhead = 400,
): Obstacle | null {
  if (path.length < 3) return null;

  for (let i = 0; i < path.length - 1; i++) {
    const distFromVehicle = Math.hypot(path[i].x - vehiclePos.x, path[i].y - vehiclePos.y);
    if (distFromVehicle < minDistAhead) continue;
    if (distFromVehicle > maxDistAhead) break;

    const types: ObstacleType[] = ['barrier', 'cow', 'pushcart', 'car'];
    const type = types[Math.floor(Math.random() * types.length)];
    const obs = makeObstacle(type, path[i].x, path[i].y);
    obs.x = path[i].x + (Math.random() - 0.5) * 10;
    obs.y = path[i].y + (Math.random() - 0.5) * 10;
    return obs;
  }

  return null;
}

export function createRandomTraffic(
  config: GridConfig,
  count = 3,
): Obstacle[] {
  const types: ObstacleType[] = ['car', 'motorcycle', 'rickshaw', 'pedestrian', 'cow', 'pushcart'];
  const obstacles: Obstacle[] = [];
  for (let i = 0; i < count; i++) {
    const type = types[Math.floor(Math.random() * types.length)];
    const x = 100 + Math.random() * (config.width - 200);
    const y = 80 + Math.random() * (config.height - 160);
    const moving = Math.random() > 0.4;
    const vx = moving ? (Math.random() - 0.5) * 0.8 : 0;
    const vy = moving ? (Math.random() - 0.5) * 0.4 : 0;
    obstacles.push(makeObstacle(type, x, y, moving, vx, vy));
  }
  return obstacles;
}

export function createObstacleAt(
  type: ObstacleType,
  x: number,
  y: number,
): Obstacle {
  return makeObstacle(type, x, y, false, 0, 0);
}

export { makeObstacle };
