import type { GridConfig, Point, Obstacle } from './types';

export interface AStarResult {
  path: Point[];
  nodesExplored: number;
  success: boolean;
}

interface AStarNode {
  col: number;
  row: number;
  g: number;
  h: number;
  f: number;
  parent: AStarNode | null;
}

export function buildGrid(
  obstacles: Obstacle[],
  config: GridConfig,
  safetyMargin: number,
): boolean[][] {
  const { cols, rows } = config;
  const blocked: boolean[][] = Array.from({ length: rows }, () =>
    new Array(cols).fill(false),
  );

  for (const obs of obstacles) {
    const minCol = Math.max(0, Math.floor((obs.x - obs.radius - safetyMargin) / config.cellSize));
    const maxCol = Math.min(cols - 1, Math.floor((obs.x + obs.radius + safetyMargin) / config.cellSize));
    const minRow = Math.max(0, Math.floor((obs.y - obs.radius - safetyMargin) / config.cellSize));
    const maxRow = Math.min(rows - 1, Math.floor((obs.y + obs.radius + safetyMargin) / config.cellSize));

    for (let r = minRow; r <= maxRow; r++) {
      for (let c = minCol; c <= maxCol; c++) {
        const cx = c * config.cellSize + config.cellSize / 2;
        const cy = r * config.cellSize + config.cellSize / 2;
        const dx = cx - obs.x;
        const dy = cy - obs.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < obs.radius + safetyMargin) {
          blocked[r][c] = true;
        }
      }
    }
  }

  return blocked;
}

const heuristic = (a: AStarNode, b: AStarNode): number => {
  const dx = Math.abs(a.col - b.col);
  const dy = Math.abs(a.row - b.row);
  return Math.sqrt(dx * dx + dy * dy);
};

const NEIGHBOR_OFFSETS = [
  { dc: -1, dr: 0 },
  { dc: 1, dr: 0 },
  { dc: 0, dr: -1 },
  { dc: 0, dr: 1 },
  { dc: -1, dr: -1 },
  { dc: 1, dr: -1 },
  { dc: -1, dr: 1 },
  { dc: 1, dr: 1 },
];

export function aStar(
  start: Point,
  goal: Point,
  blocked: boolean[][],
  config: GridConfig,
  maxIterations = 5000,
): AStarResult {
  const { cols, rows, cellSize } = config;

  const startCol = Math.round(start.x / cellSize);
  const startRow = Math.round(start.y / cellSize);
  const goalCol = Math.round(goal.x / cellSize);
  const goalRow = Math.round(goal.y / cellSize);

  if (startCol < 0 || startCol >= cols || startRow < 0 || startRow >= rows) {
    return { path: [], nodesExplored: 0, success: false };
  }
  if (goalCol < 0 || goalCol >= cols || goalRow < 0 || goalRow >= rows) {
    return { path: [], nodesExplored: 0, success: false };
  }

  const clampedStartCol = Math.max(0, Math.min(cols - 1, startCol));
  const clampedStartRow = Math.max(0, Math.min(rows - 1, startRow));
  const clampedGoalCol = Math.max(0, Math.min(cols - 1, goalCol));
  const clampedGoalRow = Math.max(0, Math.min(rows - 1, goalRow));

  const startNode: AStarNode = {
    col: clampedStartCol,
    row: clampedStartRow,
    g: 0,
    h: 0,
    f: 0,
    parent: null,
  };
  const goalNode: AStarNode = {
    col: clampedGoalCol,
    row: clampedGoalRow,
    g: 0,
    h: 0,
    f: 0,
    parent: null,
  };

  if (blocked[clampedStartRow]?.[clampedStartCol]) {
    const cleared = clearCell(blocked, clampedStartCol, clampedStartRow);
    if (!cleared) return { path: [], nodesExplored: 0, success: false };
  }
  if (blocked[clampedGoalRow]?.[clampedGoalCol]) {
    const cleared = clearCell(blocked, clampedGoalCol, clampedGoalRow);
    if (!cleared) return { path: [], nodesExplored: 0, success: false };
  }

  startNode.h = heuristic(startNode, goalNode);
  startNode.f = startNode.h;

  const openList: AStarNode[] = [startNode];
  const closedSet = new Set<string>();
  const openMap = new Map<string, AStarNode>();
  openMap.set(`${clampedStartCol},${clampedStartRow}`, startNode);

  let nodesExplored = 0;

  while (openList.length > 0 && nodesExplored < maxIterations) {
    let bestIdx = 0;
    for (let i = 1; i < openList.length; i++) {
      if (openList[i].f < openList[bestIdx].f) bestIdx = i;
    }

    const current = openList.splice(bestIdx, 1)[0];
    const key = `${current.col},${current.row}`;
    openMap.delete(key);
    closedSet.add(key);
    nodesExplored++;

    if (current.col === goalNode.col && current.row === goalNode.row) {
      const path: Point[] = [];
      let node: AStarNode | null = current;
      while (node) {
        path.unshift({
          x: node.col * cellSize + cellSize / 2,
          y: node.row * cellSize + cellSize / 2,
        });
        node = node.parent;
      }
      path[0] = { x: start.x, y: start.y };
      if (path.length > 1) {
        path[path.length - 1] = { x: goal.x, y: goal.y };
      }
      return { path, nodesExplored, success: true };
    }

    for (const { dc, dr } of NEIGHBOR_OFFSETS) {
      const nc = current.col + dc;
      const nr = current.row + dr;

      if (nc < 0 || nc >= cols || nr < 0 || nr >= rows) continue;
      const nkey = `${nc},${nr}`;
      if (closedSet.has(nkey)) continue;
      if (blocked[nr]?.[nc]) continue;

      const isDiagonal = dc !== 0 && dr !== 0;
      if (isDiagonal) {
        if (blocked[current.row]?.[nc]) continue;
        if (blocked[nr]?.[current.col]) continue;
      }

      const moveCost = isDiagonal ? Math.SQRT2 : 1;
      const g = current.g + moveCost;

      const existing = openMap.get(nkey);
      if (existing && g >= existing.g) continue;

      const neighbor: AStarNode = {
        col: nc,
        row: nr,
        g,
        h: heuristic({ col: nc, row: nr, g: 0, h: 0, f: 0, parent: null }, goalNode),
        f: 0,
        parent: current,
      };
      neighbor.f = neighbor.g + neighbor.h;

      if (existing) {
        existing.g = g;
        existing.f = g + existing.h;
        existing.parent = current;
      } else {
        openList.push(neighbor);
        openMap.set(nkey, neighbor);
      }
    }
  }

  return { path: [], nodesExplored, success: false };
}

function clearCell(blocked: boolean[][], col: number, row: number): boolean {
  if (row >= 0 && row < blocked.length && col >= 0 && col < blocked[0].length) {
    blocked[row][col] = false;
    return true;
  }
  return false;
}

export function pathLength(path: Point[]): number {
  let total = 0;
  for (let i = 1; i < path.length; i++) {
    const dx = path[i].x - path[i - 1].x;
    const dy = path[i].y - path[i - 1].y;
    total += Math.sqrt(dx * dx + dy * dy);
  }
  return total;
}

export function isPathBlocked(
  path: Point[],
  obstacles: Obstacle[],
  safetyMargin: number,
  fromIndex = 0,
): { blocked: boolean; blockedSegment: Point[] | null } {
  if (path.length < 2) return { blocked: false, blockedSegment: null };

  for (let i = fromIndex; i < path.length - 1; i++) {
    const p1 = path[i];
    const p2 = path[i + 1];
    for (const obs of obstacles) {
      if (segmentCircleIntersect(p1, p2, obs, safetyMargin)) {
        return {
          blocked: true,
          blockedSegment: [p1, p2],
        };
      }
    }
  }
  return { blocked: false, blockedSegment: null };
}

function segmentCircleIntersect(
  p1: Point,
  p2: Point,
  obs: Obstacle,
  margin: number,
): boolean {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const len2 = dx * dx + dy * dy;
  if (len2 === 0) {
    const d = Math.hypot(p1.x - obs.x, p1.y - obs.y);
    return d < obs.radius + margin;
  }
  let t = ((obs.x - p1.x) * dx + (obs.y - p1.y) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  const projX = p1.x + t * dx;
  const projY = p1.y + t * dy;
  const dist = Math.hypot(projX - obs.x, projY - obs.y);
  return dist < obs.radius + margin;
}
