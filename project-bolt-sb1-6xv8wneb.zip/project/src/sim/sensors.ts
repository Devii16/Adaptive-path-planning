import type { Obstacle, DetectedObject, SensorReadings, Vehicle, ObstacleType } from './types';

const LIDAR_MAX_RANGE = 120;
const LIDAR_RAY_COUNT = 36;
const RADAR_MAX_RANGE = 200;
const CAMERA_FOV = 60;
const CAMERA_RANGE = 100;

const RISK_DISTANCES: Record<ObstacleType, [number, number]> = {
  pedestrian: [20, 40],
  animal: [20, 40],
  cow: [20, 40],
  motorcycle: [30, 50],
  rickshaw: [25, 50],
  pushcart: [20, 45],
  car: [30, 55],
  barrier: [15, 35],
};

function computeRisk(
  type: ObstacleType,
  distance: number,
  velocity: number,
): 'Low' | 'Medium' | 'High' {
  const [close, far] = RISK_DISTANCES[type] ?? [25, 50];
  const approaching = velocity < -0.3;
  if (distance < close || (distance < close + 10 && approaching)) return 'High';
  if (distance < far) return 'Medium';
  return 'Low';
}

export function runSensors(
  vehicle: Vehicle,
  obstacles: Obstacle[],
): SensorReadings {
  const lidarRays: SensorReadings['lidarRays'] = [];
  for (let i = 0; i < LIDAR_RAY_COUNT; i++) {
    const angleOffset = (i / LIDAR_RAY_COUNT) * Math.PI * 2 - Math.PI;
    const angle = vehicle.heading + angleOffset;
    let minDist = LIDAR_MAX_RANGE;
    let hit = false;
    for (const obs of obstacles) {
      const dx = obs.x - vehicle.x;
      const dy = obs.y - vehicle.y;
      const obsDist = Math.hypot(dx, dy);
      if (obsDist > LIDAR_MAX_RANGE + obs.radius) continue;
      const obsAngle = Math.atan2(dy, dx);
      let angleDiff = obsAngle - angle;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
      if (Math.abs(angleDiff) > Math.PI / 2) continue;
      const perpDist = Math.abs(obsDist * Math.sin(angleDiff));
      if (perpDist < obs.radius) {
        const projDist = obsDist * Math.cos(angleDiff);
        if (projDist > 0 && projDist < minDist) {
          minDist = projDist;
          hit = true;
        }
      }
    }
    lidarRays.push({ angle, distance: hit ? minDist : LIDAR_MAX_RANGE, hit });
  }

  const radarContacts: SensorReadings['radarContacts'] = [];
  for (const obs of obstacles) {
    const dx = obs.x - vehicle.x;
    const dy = obs.y - vehicle.y;
    const dist = Math.hypot(dx, dy);
    if (dist > RADAR_MAX_RANGE) continue;
    const angle = Math.atan2(dy, dx);
    const relVx = obs.vx;
    const relVy = obs.vy;
    const radialVel = (relVx * dx + relVy * dy) / (dist || 1);
    radarContacts.push({ angle, distance: dist, velocity: radialVel });
  }

  const detectedObjects: DetectedObject[] = [];
  const seen = new Set<string>();
  for (const obs of obstacles) {
    const dx = obs.x - vehicle.x;
    const dy = obs.y - vehicle.y;
    const dist = Math.hypot(dx, dy);
    const angle = Math.atan2(dy, dx);
    let angleDiff = angle - vehicle.heading;
    while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
    while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
    const withinCamera = Math.abs(angleDiff) < (CAMERA_FOV / 2) * (Math.PI / 180) && dist < CAMERA_RANGE;
    const withinLidar = dist < LIDAR_MAX_RANGE;
    const withinRadar = dist < RADAR_MAX_RANGE;

    if (withinCamera || withinLidar || withinRadar) {
      if (seen.has(obs.id)) continue;
      seen.add(obs.id);
      const radialVel = (obs.vx * dx + obs.vy * dy) / (dist || 1);
      const risk = computeRisk(obs.type, dist, radialVel);
      let source: DetectedObject['source'] = 'Fusion';
      const sources = [withinCamera, withinLidar, withinRadar].filter(Boolean).length;
      if (sources >= 2) source = 'Fusion';
      else if (withinCamera) source = 'Camera';
      else if (withinLidar) source = 'LiDAR';
      else source = 'Radar';
      detectedObjects.push({
        type: obs.type,
        label: obs.label,
        distance: Math.round(dist),
        bearing: Math.round((angleDiff * 180) / Math.PI),
        risk,
        source,
      });
    }
  }

  detectedObjects.sort((a, b) => a.distance - b.distance);

  return {
    lidarRays,
    radarRange: RADAR_MAX_RANGE,
    radarContacts,
    cameraFOV: CAMERA_FOV,
    cameraRange: CAMERA_RANGE,
    detectedObjects,
  };
}

export function computeCollisionRisk(
  vehicle: Vehicle,
  obstacles: Obstacle[],
  safetyMargin: number,
): { risk: 'None' | 'Low' | 'Medium' | 'High'; nearestDistance: number } {
  let nearestDistance = Infinity;
  let nearestObstacle: Obstacle | null = null;

  for (const obs of obstacles) {
    const dist = Math.hypot(obs.x - vehicle.x, obs.y - vehicle.y) - obs.radius;
    if (dist < nearestDistance) {
      nearestDistance = dist;
      nearestObstacle = obs;
    }
  }

  if (!nearestObstacle || nearestDistance > safetyMargin * 4) {
    return { risk: 'None', nearestDistance: nearestDistance === Infinity ? 0 : nearestDistance };
  }
  if (nearestDistance < safetyMargin) return { risk: 'High', nearestDistance };
  if (nearestDistance < safetyMargin * 2) return { risk: 'Medium', nearestDistance };
  return { risk: 'Low', nearestDistance };
}

export const SENSOR_CONFIG = {
  LIDAR_MAX_RANGE,
  LIDAR_RAY_COUNT,
  RADAR_MAX_RANGE,
  CAMERA_FOV,
  CAMERA_RANGE,
};
